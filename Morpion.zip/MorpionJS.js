
let compteur = 0;
let joueur = "joueur1";
let morpion = ["","","","","","","","","",""];

function initialisation()
{   for (let i=1; i<10; i++)
    {   case_cliquee = document.getElementById("case"+i) ;
        case_cliquee.innerHTML = "" ;
        case_cliquee.style.backgroundColor = "gold" ;
    }
        morpion = ["","","","","","","","","",""];
}

function change_case(i)
{
    {case_cliquee = document.getElementById("case"+i) ;

    {if(morpion[i]=="")

    if (joueur == 1 )

       {case_cliquee.innerHTML = "O" ; 
       joueur = 2;
       morpion[i]="O"}

    else
       {case_cliquee.innerHTML = "X" ; 
       joueur = 1;
       morpion[i]="X"}

    }}
    test_gagnant();
}


function test_gagnant() {

    // Les lignes     ***************************************************                           


    let ligne1 = morpion[1]+morpion[2]+morpion[3]
    switch (ligne1)
    {case "XXX":
        for (let i=1; i<4; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=1; i<4; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

    let ligne2 = morpion[4]+morpion[5]+morpion[6]
    switch (ligne2)
    {case "XXX":
        for (let i=4; i<7; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=4; i<7; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

    let ligne3 = morpion[7]+morpion[8]+morpion[9]
    switch (ligne3)
    {case "XXX":
        for (let i=7; i<10; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=7; i<10; i=i+1)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

// Les colonnes     *************************************************

    let colonne1 = morpion[1]+morpion[4]+morpion[7]
    switch (colonne1)
    {case "XXX":
        for (let i=1; i<8; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=1; i<8; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

    let colonne2 = morpion[2]+morpion[5]+morpion[8]
    switch (colonne2)
    {case "XXX":
        for (let i=1; i<9; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=2; i<9; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

    let colonne3 = morpion[3]+morpion[6]+morpion[9]
    switch (colonne3)
    {case "XXX":
        for (let i=3; i<10; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=1; i<10; i=i+3)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

// Les diagonales     ***********************************************

    let diagonale1 = morpion[1]+morpion[5]+morpion[9]
    switch (diagonale1)
    {case "XXX":
        for (let i=1; i<10; i=i+4)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=1; i<10; i=i+4)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }

    let diagonale2 = morpion[3]+morpion[5]+morpion[7]
    switch (diagonale2)
    {case "XXX":
        for (let i=3; i<8; i=i+2)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "red" ;
            }
        alert("le joueur 1 a gagné");
        break;
    case "OOO":
        for (let i=3; i<8; i=i+2)
            {  case_cliquee = document.getElementById("case"+i) ;
                case_cliquee.style.backgroundColor = "blue" ;
            }
        alert("le joueur 2 a gagné");
        break;
    }
}